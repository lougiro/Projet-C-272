﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet
{
    public class Option
    {
        public double Strike { get;
            set; } // strike K
        public OptionType Type { get;
            set; } // call ou put grace à la class enum
        public OptionStyle Style { get;
            set; } // european ou american grace a une classe enum


        /// <summary>
        /// construteur avec param données pas le user
        /// </summary>
        /// <param name="strike"> strike </param>
        /// <param name="type"> type</param>
        /// <param name="style"> et le style</param>
        public Option(double strike, OptionType type, OptionStyle style)
        {
            this.Strike = strike;
            this.Type = type;
            this.Style = style;
        }
        /// <summary>
        /// fct qui calcule le payoff d'une option
        /// </summary>
        /// <param name="S"> sous jacent </param>
        /// <returns></returns>
        public double Payoff(double S)
        {
            if (Type == OptionType.Call)
                return Math.Max(S - Strike, 0.0);
            else
                return Math.Max(Strike - S, 0.0);
        }
    }
}
