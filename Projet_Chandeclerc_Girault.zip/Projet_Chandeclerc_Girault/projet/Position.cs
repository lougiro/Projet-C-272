﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using projet.Models.Tree;

namespace projet
{
    public class Position
    {
        // une position sera caractérisée par une option, le pricer qui est associé, une quantité et un prix d'entrée
        public Option Option { get;
            private set;}
        public CRRPricer Pricer { get;
            private set;}
        public double Quantity { get;
            private set;}
        public double EntryPrice { get;
            private set;}

        /// <summary>
        /// permet d'initailiser une position, avec les parametres de celle ci
        /// </summary>
        /// <param name="option"> option sur laquelle la position repose </param>
        /// <param name="pricer"> le pricer utile (dans notre cas tjr CRR) </param>
        /// <param name="quantity"> la quantité </param>
        public Position(Option option, CRRPricer pricer, double quantity)
        {
            this.Option = option;
            this.Pricer = pricer;
            this.Quantity = quantity;
            this.EntryPrice = pricer.Price(option); // on price l'option
        }

        /// <summary>
        /// val de marche actuelle (via le pricer)
        /// </summary>
        public double MarketValue()
        {
            return Quantity * Pricer.Price(Option);
        }

        /// <summary>
        /// fct qui va changer le pricer avec la nouvelle valeur de S et re calculer la market value
        /// </summary>
        /// <param name="S"></param>
        /// <returns></returns>
        public double UpdateValue(double S)
        {
            var pricer = new CRRPricer(S, this.Option.Strike, this.Pricer.R, this.Pricer.Sigma, this.Pricer.T, this.Pricer.Steps); // on instancie le nv pricer avec notre nv S
            this.Pricer = pricer;
            double res = MarketValue(); // on calcul la valeur avec les qty
            return res;
        }
    }
}
