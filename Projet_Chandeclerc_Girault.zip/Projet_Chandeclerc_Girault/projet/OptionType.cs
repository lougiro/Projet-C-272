﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet
{
    public enum OptionType // class enum avec le type des options (rend le code + propre)
    {
        Call,
        Put
    }
}
