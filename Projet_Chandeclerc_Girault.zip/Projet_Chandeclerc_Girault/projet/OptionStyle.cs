﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet
{
    public enum OptionStyle // class enum avec le style de l'option
    {
        European,
        American
    }
}
