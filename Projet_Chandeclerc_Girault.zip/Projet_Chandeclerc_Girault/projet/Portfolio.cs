﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet
{
    public class Portfolio
    {
        // notre portefeuille est composé d'une list de positions, ce qui va nous donner les positions totales
        private List<Position> positions; 
        /// <summary>
        /// constructeur par defaut de notre classe
        /// </summary>
        public Portfolio()
        {
            this.positions = new List<Position>();
        }

        /// <summary>
        /// ajoute à notre liste une position p
        /// </summary>
        /// <param name="p"> une position à ajouter </param>
        public void AddPosition(Position p)
        {
            positions.Add(p); // ajout de la position à la liste
        }

        public double TotalValue()
        {
            return positions.Sum(p => p.MarketValue()); // on fait la somme des market value des positions
        }

        /// <summary>
        /// permet d'avoir un "print" du ^portefeuille actuel, nous a servi au debeugage
        /// </summary>
        public void PrintPtf()
        {
            Console.WriteLine("\n Ptf global");
            foreach (var pos in positions)
            { // pour chaque position on donne le type, le style, le strike, la qty et sa valeur
                Console.WriteLine($"{pos.Option.Type} {pos.Option.Style} K={pos.Option.Strike} " +
                                  $"Qty={pos.Quantity:+#;-#;0} | Valeur={pos.MarketValue():F4}");
            }
            Console.WriteLine($"Valeur totale du portefeuille : {TotalValue():F4}");
        }

        public IReadOnlyList<Position> Positions => positions; // pour seulement lire nos pos
    }
}
