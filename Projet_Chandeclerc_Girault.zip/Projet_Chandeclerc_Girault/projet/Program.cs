﻿using System;
using projet.Models;
using projet.Models.Tree;
using projet.products;

namespace projet
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // on fixe les parametres de marché
            double S = 100.0; // prix inital du sous jacent
            double r = 0.05; // tx sans risque
            double sigma = 0.2;// vol
            double T = 1.0; // maturite
            int steps = 100; // nbr de pas du modele binomial, on le fixe à 100 car on a eu de bon resultats de comparaison
            double dt = 1.0 / 252.0; // dt

            Portfolio portfolio = new Portfolio(); // création de ptf

            Console.WriteLine("Simulation interactive de portefeuille");
            Console.WriteLine("Appuiez sur une touche pour avancer le temps (ESC pour quitter)\n");

            Random rng = new Random(); // on crée un rand
            int t = 0; // initalisation des jours

            while (true)
            {
                Console.WriteLine($"\n=== Jour {t} | Sous-jacent S = {S:F2} ==="); // on donne à quel jour on est

                double totalValue = 0.0; // initialisation de la valeur du ptf

                if (portfolio.Positions.Count > 0) // acces au compteur du ptf
                    // ainsi si on a deja des positions on les affiche
                {
                    Console.WriteLine("\nPositions actuelles :");
                    Console.WriteLine("  Type    | K   | Qty  |   Valeur actuelle");

                    foreach (var pos in portfolio.Positions) // pour chaque positions
                    {
                        //var pricer = new CRRPricer(S, pos.Option.Strike, r, sigma, T, steps); // on instancie le pricer avec notre nv S
                        //double price = pricer.Price(pos.Option); // on price
                        //double value = pos.Quantity * price; // on calcul la valeur avec les qty
                        double value = pos.UpdateValue(S);
                        totalValue += value; // puis ajout à la valeur totale du ptf
                        Console.WriteLine($"{pos.Option.Type,-5} | {pos.Option.Strike,6:F2} | {pos.Quantity,3:+#;-#;0} | {value,10:F4}");
                    }
                    // portfolio.PrintPtf();

                    Console.WriteLine($"Valeur totale du portefeuille : {totalValue:F4}"); // on print la valeur totale du ptf
                }
                else
                {
                    Console.WriteLine("(Aucune position pour l’instant)");
                }

                Console.WriteLine("--------------------------------------------");
                Console.Write("Souhaitez-vous ajouter une stratégie ? (o/n) : ");
                var input = Console.ReadLine().Trim().ToLower(); // on regarde si l'user veut ajouter une strat

                if (input == "o" || input == "oui") // verification de l'inp
                {
                    CreateStrategyMenu(portfolio, S, r, sigma, T, steps); // appelle la fct qui fait le menu des strat
                }

                Console.WriteLine("\nAppuiez sur une touche pour faire avancer le marché (ESC pour quitter)");
                var key = Console.ReadKey(true);
                if (key.Key == ConsoleKey.Escape)
                    break; // si la personne veut sortir de la console, on break

                double Z = NormalRandom(rng);
                S *= Math.Exp((r - 0.5 * sigma * sigma) * dt + sigma * Math.Sqrt(dt) * Z); // S "bouge" selon un mvt brownien géometrique

                t++; // on passe au jour suivant
                Console.Clear();
            }

            Console.WriteLine("Simulation terminée.");
        }

        static void CreateStrategyMenu(Portfolio portfolio, double S, double r, double sigma, double T, int steps)
        {
            Console.WriteLine("\n--- Choisissez une stratégie à ajouter ---");
            Console.WriteLine("1. Call Spread"); // on donne le choix de la strat (avec les chiffre
            Console.WriteLine("2. Put Spread");
            Console.WriteLine("3. Butterfly");
            Console.WriteLine("4. Seagull");
            Console.WriteLine("5. Straddle");
            Console.Write("Votre choix : ");
            string choix = Console.ReadLine().Trim();

            Strategy strategy = null;

            try
            {
                switch (choix)
                {
                    case "1":
                        Console.Write("Strike bas K1 : "); // on recupere les elements pour créer cette strat
                        double k1c = double.Parse(Console.ReadLine());
                        Console.Write("Strike haut K2 : ");
                        double k2c = double.Parse(Console.ReadLine());
                        strategy = new CallSpread(k1c, k2c, S, r, sigma, T, steps); // avec les réponses on crée notre strat
                        break; // puis on sort du switch

                    case "2":
                        Console.Write("Strike bas K1 : ");
                        double k1p = double.Parse(Console.ReadLine()); // on recupere les strick associés à la strat

                        Console.Write("Strike haut K2 : ");
                        double k2p = double.Parse(Console.ReadLine());
                        strategy = new PutSpread(k1p, k2p, S, r,sigma,T,steps); // et on la créde
                        break;
                    case "3":
                        Console.Write("Strike bas K1 : ");
                        double kb1 = double.Parse(Console.ReadLine()); // on recupere les elements

                        Console.Write("Strike moyen K2 : ");
                        double kb2 = double.Parse(Console.ReadLine());

                        Console.Write("Strike haut K3 : ");
                        double kb3 = double.Parse(Console.ReadLine());
                        strategy = new Butterfly(kb1,kb2,kb3, S, r, sigma, T, steps); // et on crée la strat
                        break;

                    case "4":
                        Console.Write("Strike call bas K1 : ");
                        double ks1 = double.Parse(Console.ReadLine());

                        Console.Write("Strike call haut K2 : ");
                        double ks2 = double.Parse(Console.ReadLine());

                        Console.Write("Strike put vendu K3 : ");
                        double ks3 = double.Parse(Console.ReadLine());

                        strategy = new Seagull(ks1, ks2, ks3, S, r, sigma, T, steps);
                        break;
                    case "5":
                        Console.Write("Strike K : ");
                        double ks = double.Parse(Console.ReadLine());
                        strategy = new Straddle(ks, S, r, sigma, T, steps);
                        break;

                    default:
                        Console.WriteLine(" attention choix invalide.");
                        return;
                }

                strategy.Build(); // on build la strat, (cad creation des options associées etc)
                strategy.AddToPortfolio(portfolio); // on ajoute la strat au ptf
                Console.WriteLine($"stratégie '{strategy.Name}' ajoutée avec succès (S={S:F2}).");
            }
            catch
            {
                Console.WriteLine("Erreur lors de la création de la strat");
            }
        }

        // genere une loi ormale centrée reduite
        static double NormalRandom(Random rng)
        {
            double u1 = 1.0 - rng.NextDouble();
            double u2 = 1.0 - rng.NextDouble();
            return Math.Sqrt(-2.0 * Math.Log(u1)) * Math.Cos(2.0 * Math.PI * u2);
        }
    }
}
