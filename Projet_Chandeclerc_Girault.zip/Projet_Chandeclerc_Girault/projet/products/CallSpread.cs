﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using projet.Models.BS;
using projet.Models.Tree;
using projet.products;

namespace projet.products
{
    public class CallSpread : Strategy
    {
        private double K1;
        private double K2;
        private double S0;
        private double R;
        private double Sigma;
        private double T;
        private int Steps;

        public CallSpread(double k1,double k2, double s0,double r,double sigma, double t,int steps):base("Call Spread")
        {
            this.K1 = k1; 
            this.K2 = k2; 
            this.S0 = s0; 
            this.R = r; 
            this.Sigma = sigma; 
            this.T = t; 
            this.Steps = steps;
        }

        public override void Build()
        {
            var call1 = new Option(K1,OptionType.Call, OptionStyle.European);
            var call2 = new Option(K2, OptionType.Call,OptionStyle.European);

            var pricer1 = new CRRPricer(this.S0,this.K1,this.R,this.Sigma, this.T, this.Steps);
            var pricer2 = new CRRPricer(this.S0, this.K2,this.R, this.Sigma,this.T, this.Steps);

            AddPosition(new Position(call1, pricer1,+1));  // achat call bas
            AddPosition(new Position(call2, pricer2,-1));  // vente call haut
        }
    }
}
