﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using projet.Models.Tree;
using projet.Models.BS;
using projet.products;


namespace projet.products
{
    public class Butterfly : Strategy
    {
        // un butterlfy herite de strategy
        // il est caractérisé par 3 strike, la sous jacent, le tx sans risque, la vol et la maturité
        private double K1;
        private double K2;
        private double K3;
        private double S0;
        private double R;
        private double Sigma;
        private double T;
        private int Steps;

        /// <summary>
        /// création d'un butterfly avec constructeur
        /// </summary>
        /// <param name="k1"></param>
        /// <param name="k2"></param>
        /// <param name="k3"></param>
        /// <param name="s0"></param>
        /// <param name="r"></param>
        /// <param name="sigma"></param>
        /// <param name="t"></param>
        /// <param name="steps"></param>
        public Butterfly(double k1, double k2, double k3, double s0, double r, double sigma, double t, int steps): base("Butterfly Spread")
        {
            this.K1 = k1; 
            this.K2 = k2; 
            this.K3 = k3; 
            this.S0 = s0; 
            this.R = r; 
            this.Sigma = sigma; 
            this.T = t; 
            this.Steps = steps;
        }
        /// <summary>
        /// permet de créer la strat
        /// </summary>
        /// <param name="S0"></param>
        /// <param name="r"></param>
        /// <param name="sigma"></param>
        /// <param name="T"></param>
        /// <param name="steps"></param>
        public override void Build()
        {
            var call1 = new Option(this.K1, OptionType.Call,OptionStyle.European); // on crée les trois option associées
            var call2 = new Option(this.K2,OptionType.Call, OptionStyle.European);
            var call3 = new Option(this.K3,OptionType.Call,OptionStyle.European);
            // on les price grace a notre CRR pricer
            var pricer1 = new CRRPricer(this.S0, this.K1,this.R, this.Sigma,this.T, this.Steps);
            var pricer2 = new CRRPricer(this.S0, this.K2, this.R, this.Sigma,this.T,this.Steps);
            var pricer3 = new CRRPricer(this.S0,this.K3,this.R, this.Sigma,this.T, this.Steps);
            // achat call K1, vente 2 calls K2, achat call K3
            AddPosition(new Position(call1,pricer1, +1));
            AddPosition(new Position(call2,pricer2, -2));
            AddPosition(new Position(call3, pricer3,+1));
        }
    }
}
