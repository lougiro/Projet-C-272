﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet.products
{
    public abstract class Strategy // classe abstraite qui va servire de schéma pour toutes nos strategies
    {
        public string Name { get; protected set; } // nom de la stratégie
        protected List<Position> positions; // liste de positions qu'il y a dans nos stratégies


        /// <summary>
        /// constructeur de strat
        /// </summary>
        /// <param name="name"> nom de la sttrategie</param>
        protected Strategy(string name)
        {
            this.Name = name;
            this.positions = new List<Position>();
        }

        /// <summary>
        /// fonction permettant d'ajouter à un portefeuille donné les positions de notre stratégie
        /// </summary>
        /// <param name="portfolio"> portefeuille </param>
        public void AddToPortfolio(Portfolio portfolio)
        {
            foreach (var pos in positions)
                portfolio.AddPosition(pos); // ajoute chaque position
            // strat est comme un "mini" ptf qui est temporaire
        }

        // ajout de position dans notre stratégie (si besoin)
        public void AddPosition(Position position)
        {
            positions.Add(position);
        }

        // calcul la market value de notre stratégie, avec ses différentes positions (surotut utile pour debeugage)
        public double MarketValue()
        {
            return positions.Sum(p => p.MarketValue());
        }

        // fct abstraite qui servira à construire nos strategies
        public abstract void Build();

        public virtual void StratShow()
        {
            Console.WriteLine($"\n Strat : {Name}");
            foreach (var pos in positions)
            {
                Console.WriteLine($"{pos.Option.Type} {pos.Option.Style} | K={pos.Option.Strike} | " +
                                  $"Qty={pos.Quantity:+#;-#;0} | Prix entrée={pos.EntryPrice:F4} | " +
                                  $"Valeur Marché={pos.MarketValue():F4}");
            }
            Console.WriteLine($"Caleur marché : {MarketValue():F4}");
        }
    }
}
