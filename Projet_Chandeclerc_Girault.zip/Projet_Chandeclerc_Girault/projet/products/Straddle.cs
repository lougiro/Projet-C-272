﻿using projet.Models.Tree;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet.products
{
    internal class Straddle : Strategy
    {
        // les atrributs classiques d'un straddle comme les autres strat
        private double K;
        private double S0;
        private double R;
        private double Sigma;
        private double T;
        private int Steps;

        /// <summary>
        /// constructeur de notre straddle qui recupere les elements de marché
        /// </summary>
        /// <param name="k"></param>
        /// <param name="s0"></param>
        /// <param name="r"></param>
        /// <param name="sigma"></param>
        /// <param name="t"></param>
        /// <param name="steps"></param>
        public Straddle(double k,double s0,double r,double sigma,double t,int steps): base("Straddle")
        {
            this.K = k;
            this.S0 = s0;
            this.R = r;
            this.Sigma = sigma;
            this.T = t;
            this.Steps = steps;
        }

        public override void Build()
        {
            // on crée les options necessaire à la création de la strat
            var call = new Option(this.K,OptionType.Call,OptionStyle.European);
            var put = new Option(this.K,OptionType.Put,OptionStyle.European);
            var pricerC = new CRRPricer(this.S0,this.K,this.R,this.Sigma,this.T,this.Steps);
            var pricerP = new CRRPricer(this.S0,this.K,this.R,this.Sigma,this.T,this.Steps);
            AddPosition(new Position(call, pricerC, +1)); // achat call
            AddPosition(new Position(put, pricerP, +1));  // achat put
        }
    }
}
