﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet.Models.BS
{
    public class BlackScholesPricer
    {
        public static double NormCDF(double x) // création de la cdf normale car pas incluse dans C#
        {
            double sign = x >= 0 ? 1.0 : -1.0;
            x = Math.Abs(x) / Math.Sqrt(2.0);

            double t = 1.0 / (1.0 + 0.3275911 * x);
            double y = 1.0 - ((((1.061405429 * t - 1.453152027) * t
                                + 1.421413741) * t - 0.284496736) * t
                                + 0.254829592) * t * Math.Exp(-x * x);

            return 0.5 * (1.0 + sign * y);
        }

        /// <summary>
        /// permet de pricer un produit grace à la formule de BS
        /// </summary>
        /// <param name="S0"> la valeur du sous jacent </param>
        /// <param name="K"> la valeur du strike </param>
        /// <param name="r"> valeur du tx sans risque </param>
        /// <param name="sigma"> valeur de la volatitlié </param>
        /// <param name="T"> valeur de la maturité </param>
        /// <param name="type"> type : prend dans la class enume call ou put</param>
        /// <returns></returns>
        public static double Price(double S0, double K, double r, double sigma, double T, OptionType type)
        {
            // calcul de d1 et d2 avec la formule connue 
            double d1 = (Math.Log(S0 / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * Math.Sqrt(T));
            double d2 = d1 - sigma * Math.Sqrt(T);

            // en fct de si le type est call ou put, on sort la formule correspondante
            if (type == OptionType.Call)
                return S0 * NormCDF(d1) - K * Math.Exp(-r * T) * NormCDF(d2);
            else
                return K * Math.Exp(-r * T) * NormCDF(-d2) - S0 * NormCDF(-d1);
        }
    }
}
