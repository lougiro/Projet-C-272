﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet.Models.Tree
{
    public class CRRPricer
    {
        public double S0 { get; } // ss jacent
        public double K { get; } // strike
        public double R { get; }   // taux sans risque (en continu)
        public double Sigma { get; }
        public double T { get; }   // maturité (en années)
        public int Steps { get; } // nbr de pas
        public double U { get; private set; } // parametre calculés selon al formule connue et exposéee lors de notre pres de cahier des charges
        public double D { get; private set; }
        public double Dt { get; private set; }
        public double Q { get; private set; }

        /// <summary>
        /// constructeur
        /// </summary>
        /// <param name="s0"></param>
        /// <param name="k"></param>
        /// <param name="r"></param>
        /// <param name="sigma"></param>
        /// <param name="t"></param>
        /// <param name="steps"></param>
        public CRRPricer(double s0, double k, double r, double sigma, double t, int steps)
        {
            this.S0 = s0;
            this.K = k;
            this.R = r;
            this.Sigma = sigma;
            this.T = t;
            this.Steps = steps;
            ComputeParameters(); // calcul les param
        }

        /// <summary>
        /// permet de calculer les parametres classiques de l'arbre trinomial
        /// </summary>
        private void ComputeParameters()
        {
            this.Dt = T / Steps;
            this.U = Math.Exp(Sigma * Math.Sqrt(Dt));
            this.D = 1.0 / U;
            this.Q = (Math.Exp(R * Dt) - D) / (U - D);
        }

        /// <summary>
        /// permet de pricer une option a partir d'un arbre
        /// </summary>
        /// <param name="option"> option qu'on veut pricer </param>
        /// <returns></returns>
        public double Price(Option option)
        {
            double rFactor = Math.Exp(R * Dt);
            BinaryTree tree = new BinaryTree(S0, U, D, rFactor, Steps); // on crée l'arbre avec les param calculés
            return tree.Price(option, Q); // puis on price
        }
    }
}
