﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet.Models.Tree
{
    public class BinaryTree
    {
        public double S0 { get; } // prix initial du ss jacent
        public double U { get; }  // facteur up
        public double D { get; }   // facteur down
        public double R { get; }  // R = 1 + r pour le cas discret ou exp pour le cas continue, le tx sans risque
        public int Steps { get; }  // nbr de pas de l'arbre, nbr d'étapes

        public double[,] StockTree { get; private set; } // matrice qui stock notre arbre
        public double[,] OptionTree { get; private set; } // matrice avec la valeurd de l'option

        /// <summary>
        /// constructeur de l'arbre
        /// </summary>
        /// <param name="s0"></param>
        /// <param name="u"></param>
        /// <param name="d"></param>
        /// <param name="r"></param>
        /// <param name="steps"></param>
        public BinaryTree(double s0, double u, double d, double r, int steps)
        {
            this.S0 = s0;
            this.U = u;
            this.D = d;
            this.R = r;
            this.Steps = steps;
            this.StockTree = new double[Steps + 1, Steps + 1]; // initalisation des matrices de l'arbre et des prix
            this.OptionTree = new double[Steps + 1, Steps + 1];

            BuildStockTree(); // on build l'arbre apres avoir récuperé les param
        }

        /// <summary>
        /// on construit l'arbre avec la formule connue pour l'arbre binomiale
        ///          S0*u^2
        ///         /
        ///     S0*u
        ///    /    \
        /// S0        S0*u*d
        ///    \    /
        ///     S0*d
        ///         \
        ///         SO*d^2
        /// 
        /// </summary>
        private void BuildStockTree()
        {
            for (int i = 0; i <= this.Steps; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    this.StockTree[j, i] = this.S0 * Math.Pow(this.U, j) * Math.Pow(this.D, i - j); // utilisation de la furmule
                    // i c'est la "colonne"
                }
            }
        }

        public void SetTerminalValues(Option option)
        {
            for (int j = 0; j <= this.Steps; j++)
                this.OptionTree[j, this.Steps] = option.Payoff(StockTree[j, this.Steps]); // on calcule les valeurs aux feuilles
            // à la fin de l'arbre dans le but d utiliser un pricer backward
        }

        public double BackwardInduction(Option option, double q)
        {
            for (int i = this.Steps - 1; i >= 0; i--)
            {
                for (int j = 0; j <= i; j++)
                {
                    double discounted = (q * this.OptionTree[j + 1, i + 1] + (1 - q) * this.OptionTree[j, i + 1]) / this.R; // on calcule la valeur
                    // du noeud
                    if (option.Style == OptionStyle.American)
                    {
                        double intrinsic = option.Payoff(this.StockTree[j, i]);
                        this.OptionTree[j, i] = Math.Max(intrinsic, discounted); // puis on donne la valeur
                        // necessaire, avec la distinction entre americaine et européenne 
                    }
                    else
                    {
                        this.OptionTree[j, i] = discounted;
                    }
                }
            }
            return this.OptionTree[0, 0]; // on retourne la valeur de l'arbre à la racine comme le veut la formule en backward
        }

        public double Price(Option option, double q)
        {
            SetTerminalValues(option); // on calcule d'abord les feuilles puis ensuite on lance le calcule backward
            return BackwardInduction(option, q);
        }
    }
}
