﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet
{
    internal class Node // classe non utilisée par le code (on voulait à la base faire une arbre avec une classe noeud mais on a
        // utilisé des listes au final
    {
        public double Price { get; set; }
        public double OptionValue { get; set; }
        public Node Up { get; set; }
        public Node Down { get; set; }

        public Node(double price)
        {
            Price = price;
            OptionValue = 0.0;
            Up = null;
            Down = null;
        }
    }
}
